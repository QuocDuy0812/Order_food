class BaseTable {
  BaseTable._();

  static const String category = 'Category';
  static const String product = 'Product';
  static const String order = 'Order';
  static const String user = 'User';
  static const String orderDetail = 'Order_Detail';
  static const String statusOrder = 'StatusOrder';
}
