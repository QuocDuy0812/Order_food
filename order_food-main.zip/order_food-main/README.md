# project_order_food

+ Using project architecture
+ Using form validate
+ Firebase: auth, firestore, storage
+ Auto upload file
+ State: Provider
+ shared preference to save local

## Getting Started

+ Đăng nhập với tư cách admin: 
  + admin@gmail.com
  + admin
+ Đăng nhập với tư cách người dùng => Tạo tài khoản
