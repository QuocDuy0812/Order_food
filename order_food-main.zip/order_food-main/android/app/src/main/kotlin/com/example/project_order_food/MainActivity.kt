package com.example.project_order_food

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
